//package com.SWP391.G3PCoffee;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class G3PCoffeeApplicationTests {
//
////	@Test
////	void contextLoads() {
////            
////	}
//
//}
