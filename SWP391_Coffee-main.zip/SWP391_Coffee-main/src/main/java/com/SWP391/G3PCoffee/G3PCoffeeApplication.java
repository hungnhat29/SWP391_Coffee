package com.SWP391.G3PCoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G3PCoffeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(G3PCoffeeApplication.class, args);
	}

}
