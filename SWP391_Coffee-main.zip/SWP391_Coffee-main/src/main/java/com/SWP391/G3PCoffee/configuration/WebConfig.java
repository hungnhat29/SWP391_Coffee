///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//
//package com.SWP391.G3PCoffee.configuration;
//
///**
// *
// * @author hungp
// */
////@Configuration
////public class WebConfig implements WebMvcConfigurer {
////    @Override
////    public void addCorsMappings(CorsRegistry registry) {
////        registry.addMapping("/api/**")
////                .allowedOrigins("http://localhost:3000")  // Thay thế với URL của frontend
////                .allowedMethods("GET", "POST", "PUT", "DELETE");
////    }
////}
//
